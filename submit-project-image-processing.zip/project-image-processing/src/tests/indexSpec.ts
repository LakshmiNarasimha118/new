import supertest from "supertest";
import app from "../index";
import sizeOf from "image-size";
import fs from "fs/promises";
import path from "path"; //importing the path.
import { Stats } from "fs"; //importing ths fs.
import imageReSize from "../helper/imageCropper";

describe("GET /", (): void => {
  //we are calling the get function here.
  it("responds with 200", (done): void => {
    supertest(app).get("/").expect(200, done);
  });
});

describe("GET /api/images", async () => {
  it("404 if called correctly but does not exist the image", (done): void => {
    supertest(app)
      .get("/crop-image?name=test&height=100&width=100")
      .expect(404, done);
  });
  it("responds with 200 if called correctly and image exist", (done): void => {
    supertest(app)
      .get("/crop-image?name=santamonica&height=100&width=100")
      .expect(200, done);
  });
  it("created a version of new image", (done) => {
    supertest(app)
      .get("/crop-image?name=santamonica&height=100&width=100")
      .then(() => {
        fs.stat(
          path.resolve(
            __dirname,
            "../../../images/newImages/santamonica-100x100.jpg"
          )
        ).then((fileStat: Stats) => expect(fileStat).not.toBeNull());
        done();
      });
  });

  it("created a thumb version of the image with the correct height and width", (done): void => {
    supertest(app)
      .get("/crop-image?name=palmtunnel&height=100&width=150")
      .then(() => {
        const dimensions = sizeOf(
          path.resolve(__dirname, "../../../images/newImages/fjord-100x150.jpg")
        );
        expect(dimensions.height).toEqual(100);
        expect(dimensions.width).toEqual(150);
        done();
      });
  });
});

const newImagePath = path.resolve(
  __dirname,
  "./../../images/newImages/santamonica.jpg"
);

const fullImagePath = path.resolve(
  __dirname,
  "./../../images/fullImages/santamonica.jpg"
);

describe("This is an image resize function", describefunction);

function describefunction(): void {
  it("If something went wrong promise will reject", async (): Promise<void> => {
    await expectAsync(
      imageReSize(150, 200, fullImagePath, newImagePath)
    ).toBeRejected();
  });
}
