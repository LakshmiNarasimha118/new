import sharp from "sharp";
const imageCropper=(
  width: number,
  height: number,
  mainPath: string,
  newPath: string
): Promise<sharp.OutputInfo> => {
  //console.log("a", width, height, mainPath, newPath);

  return sharp(mainPath).resize(width, height).toFile(newPath);
};
export default imageCropper;

